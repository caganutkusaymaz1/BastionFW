"""Pluggable, bounded detection rules for common defensive use cases."""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
import re
import time
from typing import Iterable, Protocol

from .parsing import extract_remote_ip, normalize_for_detection


@dataclass(frozen=True, slots=True)
class LogEvent:
    source: str
    line: str
    timestamp: float = field(default_factory=time.time)
    remote_ip: str | None = None


@dataclass(frozen=True, slots=True)
class Detection:
    rule: str
    severity: str
    source: str
    ip: str | None
    evidence: str
    score: int = 1


class DetectionRule(Protocol):
    def evaluate(self, event: LogEvent) -> Iterable[Detection]:
        ...


class SSHBruteForceRule:
    _failed = re.compile(r"(?:failed password|authentication failure|invalid user)", re.I)

    def __init__(self, threshold: int, window: float) -> None:
        self.threshold = threshold
        self.window = window
        self.attempts: defaultdict[str, deque[float]] = defaultdict(deque)

    def evaluate(self, event: LogEvent) -> Iterable[Detection]:
        if not self._failed.search(event.line):
            return ()
        ip = event.remote_ip or extract_remote_ip(event.line)
        if not ip:
            return ()
        bucket = self.attempts[ip]
        bucket.append(event.timestamp)
        cutoff = event.timestamp - self.window
        while bucket and bucket[0] < cutoff:
            bucket.popleft()
        if len(bucket) >= self.threshold:
            return (Detection("ssh_brute_force", "high", event.source, ip,
                              f"{len(bucket)} failed attempts/{self.window:.0f}s", len(bucket)),)
        return ()

    def purge(self, now: float) -> None:
        cutoff = now - self.window
        for ip in list(self.attempts):
            bucket = self.attempts[ip]
            while bucket and bucket[0] < cutoff:
                bucket.popleft()
            if not bucket:
                del self.attempts[ip]


class WebAttackRule:
    _patterns = {
        "sqli": re.compile(r"(?:union\s+select|select\s+.+\s+from|or\s+1\s*=\s*1|sleep\s*\()", re.I),
        "xss": re.compile(r"(?:<script|javascript:|onerror\s*=|<svg)", re.I),
        "rfi": re.compile(r"(?:https?://|ftp://).*(?:include|require)", re.I),
        "lfi_path_traversal": re.compile(r"(?:\.\./|%2e%2e|%252e|/etc/passwd|boot\.ini)", re.I),
        "command_injection": re.compile(r"(?:[;&|]\s*(?:id|whoami|uname|cat|curl|wget)|\$\()", re.I),
        "request_smuggling": re.compile(r"(?:transfer-encoding\s*:.*content-length|content-length\s*:.*transfer-encoding)", re.I),
    }

    def __init__(self, threshold: int = 2) -> None:
        self.threshold = threshold

    def evaluate(self, event: LogEvent) -> Iterable[Detection]:
        line = normalize_for_detection(event.line)
        matches = [name for name, pattern in self._patterns.items()
                   if pattern.search(line)]
        if len(matches) < self.threshold:
            return ()
        return (Detection("web_attack", "high", event.source,
                          event.remote_ip or extract_remote_ip(event.line),
                          ",".join(matches), len(matches)),)


class PrivilegeEscalationRule:
    _pattern = re.compile(
        r"(?:sudo:.*COMMAND|session opened for user root|(?:modified|opened).*/etc/(?:passwd|sudoers)|"
        r"new cron|crontab|su:.*session opened)", re.I)

    def evaluate(self, event: LogEvent) -> Iterable[Detection]:
        if self._pattern.search(event.line):
            return (Detection("privilege_escalation_anomaly", "medium", event.source,
                              event.remote_ip or extract_remote_ip(event.line),
                              event.line[:300]),)
        return ()


class DetectionEngine:
    def __init__(self, rules: Iterable[DetectionRule]) -> None:
        self.rules = tuple(rules)

    def evaluate(self, event: LogEvent) -> list[Detection]:
        detections: list[Detection] = []
        for rule in self.rules:
            detections.extend(rule.evaluate(event))
        return detections

    def purge(self, now: float | None = None) -> None:
        for rule in self.rules:
            purge = getattr(rule, "purge", None)
            if purge:
                purge(now or time.time())
